#ifndef _prog02
#define _prog02

#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

int main();

#endif
